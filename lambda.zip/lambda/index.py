import boto3 
from ddl_queries import ddls 
athena_client = boto3.client("athena", region_name = "us-west-2")

def run_query(query, bucket_name):
    try:
        print("running_query")
        loc = f's3://{bucket_name}/data/stage/athena_results/'
        
        response = athena_client.start_query_execution(
            QueryString = query,
            QueryExecutionContext = {"Database": "sandbox_ramu"}, 
            ResultConfiguration = {"OutputLocation": loc} 
        )    
         
        ex_id = response["QueryExecutionId"] 
    
        complete = False
        failed_reason = 'not_failed'
        while not complete:
            
            response = athena_client.get_query_execution(QueryExecutionId = ex_id)
            
            if response["QueryExecution"]["Status"]["State"] == "FAILED":
                print("Query failed.")
                failed_reason = response["QueryExecution"]["Status"]['StateChangeReason']
                return {'status': "Failed", "failed_reason": failed_reason, "ex_id": ex_id}
        
            elif response["QueryExecution"]["Status"]["State"] == "SUCCEEDED":
                return {'status' : "Completed", "failed_reason": None, 'ex_id': ex_id}
                
            elif response["QueryExecution"]["Status"]["State"] == "CANCELLED":
                print("Query Cancelled.")
                failed_reason = response["QueryExecution"]["Status"]['StateChangeReason']
                return {'status': "Failed", "failed_reason": failed_reason, "ex_id": ex_id} 
        else:
            time.sleep(5)
    except Exception as e:
        raise e

def lambda_handler(event, context): 
    print("event :", event)
    print(type(event))

    bucket_name = event["bucket_name"]
    processing_date = event["processing_date"]
    file_path = event["file_path"]
    update_tables = event["update_tables"]

    global env
    aws_account_id = context.invoked_function_arn.split(":")[4]
    env = 'dev' if aws_account_id == '743020291706' else 'prod'

    partitioned_tables = ["bridge_mkey2_name_history" ,"cc_multisource_master" ,"intellibase_bridge" ,"intellibase_household" ,"intellibase_individual" ,"v12_mkey2_name_history" ]

    for table_name in update_tables: 

        if table_name in partitioned_tables :

            partition_query = f'''MSCK REPAIR TABLE ib_temp.{table_name}'''
            run_query(partition_query, bucket_name)
            print(f"partition_query_successfull for {table_name}")

            drop_query = f''' DROP TABLE IF EXISTS ib_refined.{table_name} '''
            run_query(drop_query, bucket_name)
            print(f"drop query successfull for {table_name}" )
            
            create_query = ddls[table_name].format(env = env, processing_date = processing_date)
            result = run_query(create_query, bucket_name)
            print(f"DDl got created successfully for ib_refined.{table_name}")
            
            partition_query = f'''MSCK REPAIR TABLE ib_refined.{table_name}'''
            run_query(partition_query, bucket_name)
            print(f"partition_query_successfull for {table_name}")
            
        else:
            #Changing location of refined
            alter_query_refined=f"""ALTER TABLE ib_refined.{table_name} SET LOCATION 's3://{env}-cog-intellibase/data/refined/date={processing_date}/{table_name}/'"""
            run_query(alter_query_refined, bucket_name)
            print(f"refined alter query is successfull for {table_name}") 

    return event 
    
    
    
    
bridge_mkey2_name_history = '''CREATE EXTERNAL TABLE `ib_refined.bridge_mkey2_name_history`(
  `bridge_address1` string COMMENT '', 
  `bridge_address2` string COMMENT '', 
  `bridge_city` string COMMENT '', 
  `bridge_name_first` string COMMENT '', 
  `bridge_name_last` string COMMENT '', 
  `bridge_zip5` string COMMENT '', 
  `date_last_seen` string COMMENT '', 
  `mkey2` string COMMENT '', 
  `mkey5` string COMMENT '')
PARTITIONED BY ( 
  `bridge_state` string COMMENT '')
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://{env}-cog-intellibase/data/refined/date={processing_date}/bridge_mkey2_name_history/'
TBLPROPERTIES (
  'has_encrypted_data'='false', 
  'parquet.compression'='GZIP', 
  'presto_query_id'='20230713_123737_00022_tkjfn')'''
  

cc_multisource_master = ''' CREATE EXTERNAL TABLE `ib_refined.cc_multisource_master`(
  `cac_active_flag` string COMMENT '', 
  `cac_name_last` string COMMENT '', 
  `cac_production` string COMMENT '', 
  `cc_person` string COMMENT '', 
  `bridge_md5email_id` string COMMENT '', 
  `cac_addr_zip` string COMMENT '', 
  `cac_addr_zip2` string COMMENT '', 
  `cac_hh_pid` string COMMENT '', 
  `cac_name_first` string COMMENT '', 
  `cc_ind_id` string COMMENT '', 
  `cc_v12_em` string COMMENT '', 
  `domain` string COMMENT '', 
  `eps_cac_hh_pid` string COMMENT '', 
  `final_domain` string COMMENT '', 
  `flag_em_bridge` string COMMENT '', 
  `flag_em_v12` string COMMENT '', 
  `key_exact` string COMMENT '', 
  `key_substr_4` string COMMENT '', 
  `mast_latitude` string COMMENT '', 
  `mast_longitude` string COMMENT '', 
  `mkey1` string COMMENT '', 
  `mkey2` string COMMENT '', 
  `mkey3` string COMMENT '', 
  `mkey4` string COMMENT '', 
  `mkey5` string COMMENT '', 
  `source_bridge_flag` string COMMENT '', 
  `source_eps_flag` string COMMENT '', 
  `source_v12_flag` string COMMENT '', 
  `source_v12_supp_flag` string COMMENT '', 
  `v12_supp_em_id` string COMMENT '')
PARTITIONED BY ( 
  `state` string COMMENT '')
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://{env}-cog-intellibase/data/refined/date={processing_date}/cc_multisource_master/'
TBLPROPERTIES (
  'has_encrypted_data'='false', 
  'parquet.compression'='GZIP', 
  'presto_query_id'='20230713_123501_00085_5bmjr') '''


intellibase_bridge = ''' CREATE EXTERNAL TABLE `ib_refined.intellibase_bridge`(
  `bridge_address1` string COMMENT '', 
  `bridge_address2` string COMMENT '', 
  `bridge_city` string COMMENT '', 
  `bridge_md5email_id` string COMMENT '', 
  `bridge_name_first` string COMMENT '', 
  `bridge_name_last` string COMMENT '', 
  `bridge_zip5` string COMMENT '', 
  `mkey1` string COMMENT '', 
  `mkey2` string COMMENT '', 
  `mkey3` string COMMENT '', 
  `mkey4` string COMMENT '', 
  `mkey5` string COMMENT '', 
  `mkey6` string COMMENT '', 
  `mkey7` string COMMENT '')
PARTITIONED BY ( 
  `bridge_state` string COMMENT '')
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://{env}-cog-intellibase/data/refined/date={processing_date}/intellibase_bridge/'
TBLPROPERTIES (
  'has_encrypted_data'='false', 
  'parquet.compression'='GZIP', 
  'presto_query_id'='20230713_123346_00095_rw9e5') '''


intellibase_household = ''' CREATE EXTERNAL TABLE `ib_refined.intellibase_household`(
  `cac_hh_pid` string COMMENT '', 
  `mkey1` string COMMENT '', 
  `mkey2` string COMMENT '', 
  `mkey3` string COMMENT '', 
  `mkey4` string COMMENT '', 
  `mkey5` string COMMENT '', 
  `update_date` string COMMENT '', 
  `cac_hh_airconditioning` string COMMENT '', 
  `cac_addr_carrier_rt` string COMMENT '', 
  `cac_addr_carrier_route_type` string COMMENT '', 
  `cac_addr_census_tract` string COMMENT '', 
  `cac_num_contributors` string COMMENT '', 
  `cac_addr_county_code` string COMMENT '', 
  `cac_demo_credit_ranges` string COMMENT '', 
  `cac_hh_market_val` bigint COMMENT '', 
  `cac_addr_dlv_pt_code` bigint COMMENT '', 
  `cac_addr_dma` bigint COMMENT '', 
  `cac_addr_dnc_flag` bigint COMMENT '', 
  `cac_addr_dpv_status` string COMMENT '', 
  `cac_demo_hispaniccountrycode` string COMMENT '', 
  `cac_hh_homeheatindicator` string COMMENT '', 
  `cac_hh_sale_price` bigint COMMENT '', 
  `cac_demo_income_source_a` string COMMENT '', 
  `cac_hh_investment_type` string COMMENT '', 
  `cac_demo_language` string COMMENT '', 
  `cac_hh_loan_to_value` bigint COMMENT '', 
  `cac_addr_median_home_value` bigint COMMENT '', 
  `cac_addr_median_income` bigint COMMENT '', 
  `cac_hh_mtg` bigint COMMENT '', 
  `cac_hh_mortgageamt000s` bigint COMMENT '', 
  `cac_hh_mortgageloantype` string COMMENT '', 
  `cac_addr_msa` bigint COMMENT '', 
  `cac_addr_ncoa_flag` string COMMENT '', 
  `cac_hh_new_credit_range` bigint COMMENT '', 
  `cac_hh_num_credit_lines` bigint COMMENT '', 
  `cac_num_sources` bigint COMMENT '', 
  `cac_demo_occupation_micro` bigint COMMENT '', 
  `cac_hh_purch_2nd_mort_loan_type` string COMMENT '', 
  `cac_hh_purchase_lender_code` bigint COMMENT '', 
  `cac_demo_race` string COMMENT '', 
  `cac_hh_recent_2nd_lender_code` bigint COMMENT '', 
  `cac_hh_recent_2nd_lender_name` string COMMENT '', 
  `cac_hh_rec_2nd_mort_amount` bigint COMMENT '', 
  `cac_hh_rec_2nd_mort_int_rate` bigint COMMENT '', 
  `cac_hh_rec_2nd_mort_int_rt_type` string COMMENT '', 
  `cac_hh_recent_2nd_mortgage_type` string COMMENT '', 
  `cac_hh_recent_lender_code` bigint COMMENT '', 
  `cac_hh_recent_mortgage_int_rate` bigint COMMENT '', 
  `cac_hh_refinanceamount000s` bigint COMMENT '', 
  `cac_hh_refinanceamountin000scode` bigint COMMENT '', 
  `cac_hh_refinanceloantype` string COMMENT '', 
  `cac_hh_refinanceratetype` string COMMENT '', 
  `cac_demo_religion` string COMMENT '', 
  `cac_addr_resident_delivery_ind` bigint COMMENT '', 
  `cac_hh_resi_props_owned` bigint COMMENT '', 
  `cac_addr_scf` bigint COMMENT '', 
  `cac_name_suffix` string COMMENT '', 
  `cac_addr_tract_suffix` bigint COMMENT '', 
  `cac_hh_built_year` bigint COMMENT '', 
  `cac_addr_zip` string COMMENT '', 
  `cac_addr_zip4` string COMMENT '', 
  `cac_addr_congressional_district` string COMMENT '', 
  `cac_addr_cbsa_code` bigint COMMENT '', 
  `cac_addr_cbsa_division_code` bigint COMMENT '', 
  `cac_addr_cbsa_division_level` bigint COMMENT '', 
  `cac_addr_time_zone_code` bigint COMMENT '', 
  `cac_addr_census_block` bigint COMMENT '', 
  `cac_demo_income_source_b` string COMMENT '', 
  `cac_addr_statehouse_district` string COMMENT '', 
  `cac_addr_ushouse_district` string COMMENT '', 
  `cac_addr_statesenate_district` string COMMENT '', 
  `cac_addr_ussenate_district` string COMMENT '', 
  `cac_addr_id` bigint COMMENT '', 
  `cac_hh_deeddateofrefinance` string COMMENT '', 
  `cac_hh_sale_date` string COMMENT '', 
  `cac_hh_move_effective_date` string COMMENT '', 
  `cac_hh_mtg_date` string COMMENT '', 
  `cac_hh_2nd_mtg_date` string COMMENT '', 
  `cac_recno` bigint COMMENT '', 
  `cac_demo_income_source_a_numeric` bigint COMMENT '', 
  `cac_demo_income_source_b_numeric` bigint COMMENT '', 
  `cac_demo_blended_income_numeric` bigint COMMENT '', 
  `cac_int_1` boolean COMMENT '', 
  `cac_int_2` boolean COMMENT '', 
  `cac_int_3` boolean COMMENT '', 
  `cac_int_4` boolean COMMENT '', 
  `cac_int_5` boolean COMMENT '', 
  `cac_int_6` boolean COMMENT '', 
  `cac_int_7` boolean COMMENT '', 
  `cac_int_8` boolean COMMENT '', 
  `cac_int_9` boolean COMMENT '', 
  `cac_int_10` boolean COMMENT '', 
  `cac_int_11` boolean COMMENT '', 
  `cac_int_12` boolean COMMENT '', 
  `cac_int_13` boolean COMMENT '', 
  `cac_int_14` boolean COMMENT '', 
  `cac_int_15` boolean COMMENT '', 
  `cac_int_16` boolean COMMENT '', 
  `cac_int_17` boolean COMMENT '', 
  `cac_int_18` boolean COMMENT '', 
  `cac_int_19` boolean COMMENT '', 
  `cac_int_20` boolean COMMENT '', 
  `cac_int_21` boolean COMMENT '', 
  `cac_int_22` boolean COMMENT '', 
  `cac_int_23` boolean COMMENT '', 
  `cac_int_24` boolean COMMENT '', 
  `cac_int_25` boolean COMMENT '', 
  `cac_int_26` boolean COMMENT '', 
  `cac_int_27` boolean COMMENT '', 
  `cac_int_28` boolean COMMENT '', 
  `cac_int_29` boolean COMMENT '', 
  `cac_int_30` boolean COMMENT '', 
  `cac_int_31` boolean COMMENT '', 
  `cac_int_32` boolean COMMENT '', 
  `cac_int_33` boolean COMMENT '', 
  `cac_int_34` boolean COMMENT '', 
  `cac_int_35` boolean COMMENT '', 
  `cac_int_36` boolean COMMENT '', 
  `cac_int_37` boolean COMMENT '', 
  `cac_int_38` boolean COMMENT '', 
  `cac_int_39` boolean COMMENT '', 
  `cac_int_40` boolean COMMENT '', 
  `cac_int_41` boolean COMMENT '', 
  `cac_int_42` boolean COMMENT '', 
  `cac_int_43` boolean COMMENT '', 
  `cac_int_44` boolean COMMENT '', 
  `cac_int_45` boolean COMMENT '', 
  `cac_int_46` boolean COMMENT '', 
  `cac_int_47` boolean COMMENT '', 
  `cac_int_48` boolean COMMENT '', 
  `cac_int_49` boolean COMMENT '', 
  `cac_int_50` boolean COMMENT '', 
  `cac_int_51` boolean COMMENT '', 
  `cac_int_52` boolean COMMENT '', 
  `cac_int_53` boolean COMMENT '', 
  `cac_int_54` boolean COMMENT '', 
  `cac_int_55` boolean COMMENT '', 
  `cac_int_56` boolean COMMENT '', 
  `cac_int_57` boolean COMMENT '', 
  `cac_int_58` boolean COMMENT '', 
  `cac_int_59` boolean COMMENT '', 
  `cac_int_60` boolean COMMENT '', 
  `cac_int_61` boolean COMMENT '', 
  `cac_int_62` boolean COMMENT '', 
  `cac_int_63` boolean COMMENT '', 
  `cac_int_64` boolean COMMENT '', 
  `cac_int_65` boolean COMMENT '', 
  `cac_int_66` boolean COMMENT '', 
  `cac_int_67` boolean COMMENT '', 
  `cac_int_68` boolean COMMENT '', 
  `cac_int_69` boolean COMMENT '', 
  `cac_int_70` boolean COMMENT '', 
  `cac_int_71` boolean COMMENT '', 
  `cac_int_72` boolean COMMENT '', 
  `cac_int_73` boolean COMMENT '', 
  `cac_int_74` boolean COMMENT '', 
  `cac_int_75` boolean COMMENT '', 
  `cac_int_76` boolean COMMENT '', 
  `cac_int_77` boolean COMMENT '', 
  `cac_int_78` boolean COMMENT '', 
  `cac_int_79` boolean COMMENT '', 
  `cac_int_80` boolean COMMENT '', 
  `cac_int_81` boolean COMMENT '', 
  `cac_int_82` boolean COMMENT '', 
  `cac_int_83` boolean COMMENT '', 
  `cac_int_84` boolean COMMENT '', 
  `cac_int_85` boolean COMMENT '', 
  `cac_int_86` boolean COMMENT '', 
  `cac_int_87` boolean COMMENT '', 
  `cac_int_88` boolean COMMENT '', 
  `cac_int_89` boolean COMMENT '', 
  `cac_int_90` boolean COMMENT '', 
  `cac_int_91` boolean COMMENT '', 
  `cac_int_92` boolean COMMENT '', 
  `cac_int_93` boolean COMMENT '', 
  `cac_int_94` boolean COMMENT '', 
  `cac_int_95` boolean COMMENT '', 
  `cac_int_96` boolean COMMENT '', 
  `cac_int_97` boolean COMMENT '', 
  `cac_int_98` boolean COMMENT '', 
  `cac_int_99` boolean COMMENT '', 
  `cac_int_100` boolean COMMENT '', 
  `cac_int_101` boolean COMMENT '', 
  `cac_int_102` boolean COMMENT '', 
  `cac_int_103` boolean COMMENT '', 
  `cac_int_104` boolean COMMENT '', 
  `cac_int_105` boolean COMMENT '', 
  `cac_int_106` boolean COMMENT '', 
  `cac_int_107` boolean COMMENT '', 
  `cac_int_108` boolean COMMENT '', 
  `cac_int_109` boolean COMMENT '', 
  `cac_int_110` boolean COMMENT '', 
  `cac_int_111` boolean COMMENT '', 
  `cac_int_112` boolean COMMENT '', 
  `cac_int_113` boolean COMMENT '', 
  `cac_int_114` boolean COMMENT '', 
  `cac_int_115` boolean COMMENT '', 
  `cac_int_116` boolean COMMENT '', 
  `cac_int_117` boolean COMMENT '', 
  `cac_int_118` boolean COMMENT '', 
  `cac_int_119` boolean COMMENT '', 
  `cac_int_120` boolean COMMENT '', 
  `cac_int_121` boolean COMMENT '', 
  `cac_int_122` boolean COMMENT '', 
  `cac_int_123` boolean COMMENT '', 
  `cac_int_124` boolean COMMENT '', 
  `cac_int_125` boolean COMMENT '', 
  `cac_int_126` boolean COMMENT '', 
  `cac_int_127` boolean COMMENT '', 
  `cac_int_128` boolean COMMENT '', 
  `cac_int_129` boolean COMMENT '', 
  `cac_int_130` boolean COMMENT '', 
  `cac_int_131` boolean COMMENT '', 
  `cac_int_132` boolean COMMENT '', 
  `cac_int_133` boolean COMMENT '', 
  `cac_int_134` boolean COMMENT '', 
  `cac_int_135` boolean COMMENT '', 
  `cac_int_136` boolean COMMENT '', 
  `cac_int_137` boolean COMMENT '', 
  `cac_int_138` boolean COMMENT '', 
  `cac_int_139` boolean COMMENT '', 
  `cac_int_140` boolean COMMENT '', 
  `cac_int_141` boolean COMMENT '', 
  `cac_int_142` boolean COMMENT '', 
  `cac_int_143` boolean COMMENT '', 
  `cac_int_144` boolean COMMENT '', 
  `cac_int_145` boolean COMMENT '', 
  `cac_int_146` boolean COMMENT '', 
  `cac_int_147` boolean COMMENT '', 
  `cac_int_148` boolean COMMENT '', 
  `cac_int_149` boolean COMMENT '', 
  `cac_int_150` boolean COMMENT '', 
  `cac_int_151` boolean COMMENT '', 
  `cac_int_152` boolean COMMENT '', 
  `cac_int_153` boolean COMMENT '', 
  `cac_int_154` boolean COMMENT '', 
  `cac_int_155` boolean COMMENT '', 
  `cac_int_156` boolean COMMENT '', 
  `cac_int_157` boolean COMMENT '', 
  `cac_int_158` boolean COMMENT '', 
  `cac_int_159` boolean COMMENT '', 
  `cac_int_160` boolean COMMENT '', 
  `cac_int_161` boolean COMMENT '', 
  `cac_int_162` boolean COMMENT '', 
  `cac_int_163` boolean COMMENT '', 
  `cac_int_164` boolean COMMENT '', 
  `cac_int_165` boolean COMMENT '', 
  `cac_int_166` boolean COMMENT '', 
  `cac_int_167` boolean COMMENT '', 
  `cac_int_168` boolean COMMENT '', 
  `cac_int_169` boolean COMMENT '', 
  `cac_int_170` boolean COMMENT '', 
  `cac_int_pol_donor` bigint COMMENT '', 
  `cac_int_mail_buy` bigint COMMENT '', 
  `cac_int_mail_donor` bigint COMMENT '', 
  `cac_int_pol_party` bigint COMMENT '', 
  `cac_cred_premium_discover` boolean COMMENT '', 
  `cac_cred_premium_visa_or_mc` boolean COMMENT '', 
  `cac_cred_regular_discover` boolean COMMENT '', 
  `cac_cred_card_newissue` boolean COMMENT '', 
  `cac_cred_presence_premium_card` boolean COMMENT '', 
  `cac_cred_amex` boolean COMMENT '', 
  `cac_cred_any` boolean COMMENT '', 
  `cac_cred_mastercard` boolean COMMENT '', 
  `cac_cred_std_retail` boolean COMMENT '', 
  `cac_cred_std_specialty` boolean COMMENT '', 
  `cac_cred_travel` boolean COMMENT '', 
  `cac_cred_visa` boolean COMMENT '', 
  `cac_cred_auto_parts_repair` boolean COMMENT '', 
  `cac_cred_presence_gld_plt_card` boolean COMMENT '', 
  `cac_int_catalog_resp` bigint COMMENT '', 
  `cac_int_high_tech_leader` boolean COMMENT '', 
  `cac_addr_soho_business` boolean COMMENT '', 
  `cac_demo_child_age00_03gender` bigint COMMENT '', 
  `cac_demo_child_age04_06gender` bigint COMMENT '', 
  `cac_demo_child_age07_09gender` bigint COMMENT '', 
  `cac_demo_child_age10_12gender` bigint COMMENT '', 
  `cac_demo_child_age13_18gender` bigint COMMENT '', 
  `cac_hh_truck_owner` boolean COMMENT '', 
  `cac_hh_veteran_in_household` boolean COMMENT '', 
  `cac_hh_voter_indicator` boolean COMMENT '', 
  `cac_hh_travel_personal` boolean COMMENT '', 
  `cac_demo_working_woman` boolean COMMENT '', 
  `cac_demo_young_adult_in_hh` boolean COMMENT '', 
  `cac_hh_mail_responder` boolean COMMENT '', 
  `cac_demo_elderly_parent` boolean COMMENT '', 
  `cac_demo_grandchildren_0_12` boolean COMMENT '', 
  `cac_hh_owns_satellite_tv` boolean COMMENT '', 
  `cac_ind1_birthdate` string COMMENT '', 
  `cac_ind2_birthdate` string COMMENT '', 
  `cac_ind3_birthdate` string COMMENT '', 
  `cac_ind4_birthdate` string COMMENT '', 
  `cac_ind5_birthdate` string COMMENT '', 
  `cac_name_first` string COMMENT '', 
  `cac_name_last` string COMMENT '', 
  `cac_ind1_age` bigint COMMENT '', 
  `cac_ind2_age` bigint COMMENT '', 
  `cac_ind3_age` bigint COMMENT '', 
  `cac_ind4_age` bigint COMMENT '', 
  `cac_ind5_age` bigint COMMENT '', 
  `cac_ind1_email` string COMMENT '', 
  `cac_ind2_email` string COMMENT '', 
  `cac_ind3_email` string COMMENT '', 
  `cac_ind4_email` string COMMENT '', 
  `cac_ind5_email` string COMMENT '', 
  `cac_ind1_gender` string COMMENT '', 
  `cac_ind2_gender` string COMMENT '', 
  `cac_ind3_gender` string COMMENT '', 
  `cac_ind4_gender` string COMMENT '', 
  `cac_ind5_gender` string COMMENT '', 
  `cac_ind1_id` bigint COMMENT '', 
  `cac_ind2_id` bigint COMMENT '', 
  `cac_ind3_id` bigint COMMENT '', 
  `cac_ind4_id` bigint COMMENT '', 
  `cac_ind5_id` bigint COMMENT '', 
  `cac_ind1_mi` string COMMENT '', 
  `cac_ind2_mi` string COMMENT '', 
  `cac_ind3_mi` string COMMENT '', 
  `cac_ind4_mi` string COMMENT '', 
  `cac_ind5_mi` string COMMENT '', 
  `cac_ind1_name` string COMMENT '', 
  `cac_ind2_name` string COMMENT '', 
  `cac_ind3_name` string COMMENT '', 
  `cac_ind4_name` string COMMENT '', 
  `cac_ind5_name` string COMMENT '', 
  `cac_ind1_relationship` string COMMENT '', 
  `cac_ind2_relationship` string COMMENT '', 
  `cac_ind3_relationship` string COMMENT '', 
  `cac_ind4_relationship` string COMMENT '', 
  `cac_ind5_relationship` string COMMENT '', 
  `cac_ind1_education` bigint COMMENT '', 
  `cac_ind2_education` bigint COMMENT '', 
  `cac_ind3_education` bigint COMMENT '', 
  `cac_ind4_education` bigint COMMENT '', 
  `cac_ind5_education` bigint COMMENT '', 
  `cac_ind1_marital_s` bigint COMMENT '', 
  `cac_ind2_marital_s` bigint COMMENT '', 
  `cac_ind3_marital_s` bigint COMMENT '', 
  `cac_ind4_marital_s` bigint COMMENT '', 
  `cac_ind5_marital_s` bigint COMMENT '', 
  `cac_v12_em_flag` boolean COMMENT '', 
  `cac_int_num` bigint COMMENT '', 
  `cac_hh_gen_z_in_home` bigint COMMENT '', 
  `cac_hh_gen_x_in_home` bigint COMMENT '', 
  `cac_hh_millenial_in_home` bigint COMMENT '', 
  `cac_cred_bank` bigint COMMENT '', 
  `cac_addr_city` string COMMENT '', 
  `cac_addr_zip2` string COMMENT '', 
  `cac_addr_full` string COMMENT '', 
  `cac_addr_latitude` double COMMENT '', 
  `cac_addr_longitude` double COMMENT '', 
  `cac_active_flag` boolean COMMENT '', 
  `cac_year` bigint COMMENT '', 
  `cac_quarter` bigint COMMENT '', 
  `cac_production` bigint COMMENT '', 
  `cac_prod_active_flag` bigint COMMENT '', 
  `cac_demo_kids_00_03` boolean COMMENT '', 
  `cac_demo_kids_04_06` boolean COMMENT '', 
  `cac_demo_kids_07_09` boolean COMMENT '', 
  `cac_demo_kids_10_12` boolean COMMENT '', 
  `cac_demo_kids_13_18` boolean COMMENT '', 
  `cac_demo_kids` boolean COMMENT '', 
  `cac_demo_num_kids` bigint COMMENT '', 
  `cac_demo_adult_18_24` bigint COMMENT '', 
  `cac_demo_adult_25_34` bigint COMMENT '', 
  `cac_demo_adult_35_44` bigint COMMENT '', 
  `cac_demo_adult_45_54` bigint COMMENT '', 
  `cac_demo_adult_55_64` bigint COMMENT '', 
  `cac_demo_adult_65_74` bigint COMMENT '', 
  `cac_demo_adult_75_plus` bigint COMMENT '', 
  `cac_demo_adult_unknown` bigint COMMENT '', 
  `cac_demo_adult_under_35_inf` bigint COMMENT '', 
  `cac_demo_adult_35_44_inf` bigint COMMENT '', 
  `cac_demo_adult_45_64_inf` bigint COMMENT '', 
  `cac_demo_adult_65_plus_inf` bigint COMMENT '', 
  `cac_demo_hoh_age` bigint COMMENT '', 
  `cac_demo_net_worth` bigint COMMENT '', 
  `cac_demo_num_in_hh` bigint COMMENT '', 
  `cac_demo_num_adults` bigint COMMENT '', 
  `cac_demo_num_generations` bigint COMMENT '', 
  `cac_demo_hh_size` bigint COMMENT '', 
  `cac_int_flag` boolean COMMENT '', 
  `cac_demo_education` bigint COMMENT '', 
  `cac_demo_marital_status` bigint COMMENT '', 
  `cac_demo_hh_type` bigint COMMENT '', 
  `cac_demo_occupation` bigint COMMENT '', 
  `cac_hh_dwell_type` bigint COMMENT '', 
  `cac_hh_home_own` bigint COMMENT '', 
  `cac_demo_income` string COMMENT '', 
  `cac_demo_income_index` double COMMENT '', 
  `cac_hh_res_length_years` bigint COMMENT '', 
  `cac_hh_res_length` bigint COMMENT '', 
  `cac_hh_bridge_em_flag` boolean COMMENT '', 
  `cac_bridge_ind_matched_1` bigint COMMENT '', 
  `cac_bridge_ind_matched_2` bigint COMMENT '', 
  `cac_bridge_ind_matched_3` bigint COMMENT '', 
  `cac_bridge_ind_matched_4` string COMMENT '', 
  `cac_bridge_ind_matched_5` string COMMENT '', 
  `cac_bridge_ind_matchkeys_1` bigint COMMENT '', 
  `cac_bridge_ind_matchkeys_2` bigint COMMENT '', 
  `cac_bridge_ind_matchkeys_3` bigint COMMENT '', 
  `cac_bridge_ind_matchkeys_4` string COMMENT '', 
  `cac_bridge_ind_matchkeys_5` string COMMENT '', 
  `cac_hh_bridge_ind_matched_flag` bigint COMMENT '', 
  `cac_demo_age_fill_level` string COMMENT '', 
  `cac_demo_income_fill_level` string COMMENT '', 
  `cac_home_sq_foot_num` bigint COMMENT '', 
  `cac_demo_sq_ft_fill_level` string COMMENT '', 
  `cac_int_factor1` double COMMENT '', 
  `cac_int_factor2` double COMMENT '', 
  `cac_int_factor3` double COMMENT '', 
  `cac_int_factor4` double COMMENT '', 
  `cac_int_factor5` double COMMENT '', 
  `cac_int_factor6` string COMMENT '', 
  `cac_int_factor7` double COMMENT '', 
  `cac_int_factor8` double COMMENT '', 
  `cac_int_factor9` double COMMENT '', 
  `cac_int_factor10` double COMMENT '', 
  `cac_int_factor11` double COMMENT '', 
  `cac_int_factor12` double COMMENT '', 
  `cac_int_factor13` string COMMENT '', 
  `cac_int_factor14` string COMMENT '', 
  `cac_int_factor15` double COMMENT '', 
  `cac_int_factor16` double COMMENT '', 
  `cac_int_factor17` string COMMENT '', 
  `cac_int_factor18` string COMMENT '', 
  `cac_int_factor19` double COMMENT '', 
  `cac_int_factor20` string COMMENT '', 
  `match_zip2` string COMMENT '', 
  `cac_census_id` bigint COMMENT '', 
  `cac_census_match` boolean COMMENT '', 
  `cac_census_match_level` string COMMENT '', 
  `cen_hsecost_14` double COMMENT '', 
  `cen_hsecost_21` double COMMENT '', 
  `cen_hsecost_30` double COMMENT '', 
  `cen_hserent_4` double COMMENT '', 
  `cac_silh_lifestyle` bigint COMMENT '', 
  `cac_silh_buy_style_group` bigint COMMENT '', 
  `cac_silh_tech` bigint COMMENT '', 
  `cac_silh_ecom` bigint COMMENT '', 
  `cac_silh_social` bigint COMMENT '', 
  `cac_silh_dig_inf` bigint COMMENT '', 
  `cac_silh_lstyle_macro` bigint COMMENT '', 
  `cac_silh_loyal` bigint COMMENT '', 
  `cac_silh_price` bigint COMMENT '', 
  `cac_addr_geo_match_level` string COMMENT '', 
  `cac_silh_buy_style_rank_1` bigint COMMENT '', 
  `cac_silh_buy_style_rank_2` bigint COMMENT '', 
  `cac_silh_buy_style_rank_3` bigint COMMENT '', 
  `cac_silh_buy_style_rank_4` bigint COMMENT '', 
  `cac_silh_buy_style_rank_5` bigint COMMENT '', 
  `cac_silh_buy_style_rank_6` bigint COMMENT '', 
  `cac_demo_hoh_gender` string COMMENT '', 
  `cac_lifestage` string COMMENT '', 
  `cac_silh_lifestage_group` bigint COMMENT '', 
  `cac_demo_monthly_disp_inc_at_num` double COMMENT '', 
  `cac_demo_monthly_inc` double COMMENT '', 
  `cac_demo_monthly_disp_inc_num` double COMMENT '', 
  `cac_demo_monthly_disp_inc` bigint COMMENT '', 
  `cac_demo_monthly_disp_inc_at` bigint COMMENT '', 
  `cac_silh_socio_econ` bigint COMMENT '', 
  `cac_silh_socio_group` bigint COMMENT '', 
  `cac_silh_geo` string COMMENT '', 
  `cac_silh_geo_lc` bigint COMMENT '', 
  `cac_silh_socio_income` bigint COMMENT '', 
  `cac_silh_socio_ho` bigint COMMENT '', 
  `cac_silh_lifestage_comp` bigint COMMENT '', 
  `cac_silh_lifestage_age` bigint COMMENT '', 
  `cac_silh` string COMMENT '', 
  `cac_silh_super` string COMMENT '', 
  `global_control_display` boolean COMMENT '', 
  `interests` string COMMENT '')
PARTITIONED BY ( 
  `cac_addr_state` string COMMENT '')
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://{env}-cog-intellibase/data/refined/date={processing_date}/intellibase_household/'
TBLPROPERTIES (
  'has_encrypted_data'='false', 
  'parquet.compression'='GZIP', 
  'presto_query_id'='20230713_134101_00112_ij5ps') '''
  
  
intellibase_individual = ''' CREATE EXTERNAL TABLE `ib_refined.intellibase_individual`(
  `cac_indiv_id` bigint COMMENT '', 
  `cac_hh_pid` string COMMENT '', 
  `ind_age` bigint COMMENT '', 
  `ind_birthdate` string COMMENT '', 
  `ind_education` bigint COMMENT '', 
  `ind_email` string COMMENT '', 
  `ind_email_v12` bigint COMMENT '', 
  `ind_gender` bigint COMMENT '', 
  `ind_name_last` string COMMENT '', 
  `ind_name_first` string COMMENT '', 
  `ind_marital_status` string COMMENT '', 
  `ind_mi` string COMMENT '', 
  `ind_relationship` string COMMENT '', 
  `ind_email_bridge` string COMMENT '', 
  `ind_active_flag` bigint COMMENT '', 
  `bridge_name_first` string COMMENT '', 
  `bridge_md5email_id` string COMMENT '', 
  `cac_ind_gen_x` bigint COMMENT '', 
  `cac_ind_millenial` bigint COMMENT '', 
  `cac_ind_gen_z` bigint COMMENT '', 
  `ind_household_rank` bigint COMMENT '', 
  `cac_addr_zip` string COMMENT '', 
  `cac_addr_full` string COMMENT '')
PARTITIONED BY ( 
  `cac_addr_state` string COMMENT '')
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://{env}-cog-intellibase/data/refined/date={processing_date}/intellibase_individual/'
TBLPROPERTIES (
  'has_encrypted_data'='false', 
  'parquet.compression'='GZIP', 
  'presto_query_id'='20230713_123710_00058_ye257') '''


v12_mkey2_name_history = ''' CREATE EXTERNAL TABLE `ib_refined.v12_mkey2_name_history`(
  `date_last_seen` string COMMENT '', 
  `mkey2` string COMMENT '', 
  `mkey5` string COMMENT '', 
  `v12_addr_1` string COMMENT '', 
  `v12_addr_2` string COMMENT '', 
  `v12_addr_city` string COMMENT '', 
  `v12_addr_zip` string COMMENT '', 
  `v12_name_first` string COMMENT '', 
  `v12_name_last` string COMMENT '')
PARTITIONED BY ( 
  `v12_addr_state` string COMMENT '')
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://{env}-cog-intellibase/data/refined/date={processing_date}/v12_mkey2_name_history/'
TBLPROPERTIES (
  'has_encrypted_data'='false', 
  'parquet.compression'='GZIP', 
  'presto_query_id'='20230713_123758_00016_jrd3w') '''

ddls = {'bridge_mkey2_name_history': bridge_mkey2_name_history, 'cc_multisource_master': cc_multisource_master, 'intellibase_bridge': intellibase_bridge, 'intellibase_individual': intellibase_individual, 'v12_mkey2_name_history': v12_mkey2_name_history, 'intellibase_household': intellibase_household}
