import boto3 
from ddl_queries import ddls 
athena_client = boto3.client("athena", region_name = "us-west-2")

def run_query(query, bucket_name):
    try:
        print("running_query")
        loc = f's3://{bucket_name}/data/stage/athena_results/'
        
        response = athena_client.start_query_execution(
            QueryString = query,
            QueryExecutionContext = {"Database": "sandbox_ramu"}, 
            ResultConfiguration = {"OutputLocation": loc} 
        )    
         
        ex_id = response["QueryExecutionId"] 
    
        complete = False
        failed_reason = 'not_failed'
        while not complete:
            
            response = athena_client.get_query_execution(QueryExecutionId = ex_id)
            
            if response["QueryExecution"]["Status"]["State"] == "FAILED":
                print("Query failed.")
                failed_reason = response["QueryExecution"]["Status"]['StateChangeReason']
                return {'status': "Failed", "failed_reason": failed_reason, "ex_id": ex_id}
        
            elif response["QueryExecution"]["Status"]["State"] == "SUCCEEDED":
                return {'status' : "Completed", "failed_reason": None, 'ex_id': ex_id}
                
            elif response["QueryExecution"]["Status"]["State"] == "CANCELLED":
                print("Query Cancelled.")
                failed_reason = response["QueryExecution"]["Status"]['StateChangeReason']
                return {'status': "Failed", "failed_reason": failed_reason, "ex_id": ex_id} 
        else:
            time.sleep(5)
    except Exception as e:
        raise e

def lambda_handler(event, context): 
    print("event :", event)
    print(type(event))

    bucket_name = event["bucket_name"]
    processing_date = event["processing_date"]
    file_path = event["file_path"]
    update_tables = event["update_tables"]

    global env
    aws_account_id = context.invoked_function_arn.split(":")[4]
    env = 'dev' if aws_account_id == '743020291706' else 'prod'

    partitioned_tables = ["bridge_mkey2_name_history" ,"cc_multisource_master" ,"intellibase_bridge" ,"intellibase_household" ,"intellibase_individual" ,"v12_mkey2_name_history" ]

    for table_name in update_tables: 

        if table_name in partitioned_tables :

            partition_query = f'''MSCK REPAIR TABLE ib_temp.{table_name}'''
            run_query(partition_query, bucket_name)
            print(f"partition_query_successfull for {table_name}")

            drop_query = f''' DROP TABLE IF EXISTS ib_refined.{table_name} '''
            run_query(drop_query, bucket_name)
            print(f"drop query successfull for {table_name}" )
            
            create_query = ddls[table_name].format(env = env, processing_date = processing_date)
            result = run_query(create_query, bucket_name)
            print(f"DDl got created successfully for ib_refined.{table_name}")
            
            partition_query = f'''MSCK REPAIR TABLE ib_refined.{table_name}'''
            run_query(partition_query, bucket_name)
            print(f"partition_query_successfull for {table_name}")
            
        else:
            #Changing location of refined
            alter_query_refined=f"""ALTER TABLE ib_refined.{table_name} SET LOCATION 's3://{env}-cog-intellibase/data/refined/date={processing_date}/{table_name}/'"""
            run_query(alter_query_refined, bucket_name)
            print(f"refined alter query is successfull for {table_name}") 

    return event 
    
